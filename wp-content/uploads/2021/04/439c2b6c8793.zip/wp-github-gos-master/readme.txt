=== Github Object Storage Plugins ===
Contributors: sy-records
Donate link: https://qq52o.me/sponsor.html
Tags: gos, github, 对象存储
Requires at least: 4.2
Tested up to: 4.9.5
Stable tag: 4.3
Requires PHP: 5.4.0
Stable tag: 1.0
License: MIT
License URI: 

使用 Github 仓库作为附件存储空间。（This is a plugin that uses Github for attachments remote saving.）

== Description ==

使用 Github 仓库作为附件存储空间。（This is a plugin that uses Github for attachments remote saving.）

== Installation ==

1. Upload the folder `gos-sync` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. That's all

== Screenshots ==

1.WordPress settings after installing this plugin

== Changelog ==

= 1.0 =
* First version

== Upgrade Notice ==
